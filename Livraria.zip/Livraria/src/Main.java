import java.util.List;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        LivroDAO dao = new LivroDAO();
        dao.criarTabelaSeNaoExistir(); // Criando Tabela de Livros

        int opcao = -1;
        while (opcao != 5) {
            String menu = """
                          === CRUD de Livros ===
                          1 - Cadastrar livro
                          2 - Listar livros
                          3 - Atualizar livro
                          4 - Excluir livro
                          5 - Sair
                          
                          Escolha uma opção:
                          """;

            try {
                String entrada = JOptionPane.showInputDialog(null, menu);

                // Se o usuário clicar em "Cancelar" ou fechar a janela, o 'entrada' será null
                if (entrada == null) {
                    opcao = 5; // Força a saída do programa
                    continue;
                }

                opcao = Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Opção escolhida inválida, tente um número de 1 a 5");
                continue;
            }

            switch (opcao) {
                case 1 -> {
                    try {
                        String titulo = JOptionPane.showInputDialog("Título: ");
                        String autor = JOptionPane.showInputDialog("Autor: ");
                        int paginas = Integer.parseInt(JOptionPane.showInputDialog("Páginas: "));
                        String lido = JOptionPane.showInputDialog("Lido (Sim/Não): ");

                        Livro l = new Livro(titulo, autor, paginas, lido);
                        dao.inserir(l);
                        JOptionPane.showMessageDialog(null, "Livro cadastrado com sucesso!");
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Erro: No campo páginas você deve digitar um número inteiro.");
                    }
                }
                case 2 -> {
                    List<Livro> lista = dao.listar();
                    if (lista.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Nenhum livro cadastrado ");
                    } else {
                        // Otimizado: Mostra todos os livros juntos em vez de abrir várias caixas
                        StringBuilder sb = new StringBuilder("=== Livros Cadastrados ===\n\n");
                        lista.forEach(livro -> sb.append(livro.toString()).append("\n"));
                        JOptionPane.showMessageDialog(null, sb.toString());
                    }
                }
                case 3 -> {
                    int id;
                    try {
                        id = Integer.parseInt(JOptionPane.showInputDialog("ID do Livro a atualizar: "));
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "ID Inválido");
                        break;
                    }

                    try {
                        String novoTitulo = JOptionPane.showInputDialog("Novo Título: ");
                        String novoAutor = JOptionPane.showInputDialog("Novo Autor: ");
                        int novoPaginas = Integer.parseInt(JOptionPane.showInputDialog("Nova QTD Páginas: "));
                        String novoLido = JOptionPane.showInputDialog("Novo STATUS de Lido: ");

                        Livro up = new Livro(novoTitulo, novoAutor, novoPaginas, novoLido);
                        up.setId(id);
                        dao.atualizar(up);
                        JOptionPane.showMessageDialog(null, "Livro atualizado com sucesso!");
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Erro ao atualizar: Quantidade de páginas inválida.");
                    }
                }
                case 4 -> {
                    int idDel;
                    try {
                        idDel = Integer.parseInt(JOptionPane.showInputDialog("ID do Livro a deletar: "));
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "ID Inválido");
                        break;
                    }
                    dao.deletar(idDel);
                    JOptionPane.showMessageDialog(null, "Livro excluído com sucesso!");
                }
                case 5 -> JOptionPane.showMessageDialog(null, "Saindo....");
                default -> JOptionPane.showMessageDialog(null, "Opção Inválida. Tente de 1 a 5.");
            }
        }

        JOptionPane.showMessageDialog(null, "Programa Encerrado");
    }
}
