import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class LivroDAO {
    public void criarTabelaSeNaoExistir() {
        String sql = """
        CREATE TABLE IF NOT EXISTS livros (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT,
            autor TEXT,
            paginas INTEGER,
            lido TEXT NOT NULL
        );
        """;
        try (Connection conn = LivroController.conectar();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }



    }
    public void inserir(Livro l) {
        String sql = "INSERT INTO livros (titulo, autor, paginas, lido) VALUES (?, ?, ?, ?);";
        try (Connection conn = LivroController.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, l.getTitulo());
            ps.setString(2, l.getAutor());
            ps.setInt(3, l.getPaginas());
            ps.setString(4, l.getLido());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Livro cadastrado com sucesso!");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir livro: " + e.getMessage());
        }
    }
    public List<Livro> listar() {
        List<Livro> lista = new ArrayList<>();
        String sql = "SELECT id, titulo, autor, paginas, lido FROM livros";
        try (Connection conn = LivroController.conectar();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Livro l = new Livro();
                l.setId(rs.getInt("id"));
                l.setTitulo(rs.getString("titulo"));
                l.setAutor(rs.getString("autor"));
                l.setPaginas(rs.getInt("paginas"));
                l.setLido(rs.getString("lido"));
                lista.add(l);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar livros: " + e.getMessage());
        }
        return lista;
    }
    public void atualizar(Livro l) {
        String sql = "UPDATE livros SET titulo = ?, autor = ?, paginas = ?, lido = ? WHERE id = ?";
        try (Connection conn = LivroController.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, l.getTitulo());
            ps.setString(2, l.getAutor());
            ps.setInt(3, l.getPaginas());
            ps.setString(4, l.getLido());
            ps.setInt(5, l.getId());
            int linhas = ps.executeUpdate();
            if (linhas > 0) {
                JOptionPane.showMessageDialog(null, "Livro atualizado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum livro encontrado com esse ID");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar livro: " + e.getMessage());
        }
    }
    public void deletar(int id) {
        String sql = "DELETE FROM livros WHERE id = ?";
        try (Connection conn = LivroController.conectar();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int linhas = ps.executeUpdate();
            if (linhas > 0) {
                JOptionPane.showMessageDialog(null, "Livro delatado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "Nenhum livro encontrado com esse ID");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar livro: " + e.getMessage());
        }
    }

}
